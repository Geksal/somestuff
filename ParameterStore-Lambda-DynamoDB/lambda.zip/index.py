import json
import os
import boto3
import uuid
import logging
from datetime import datetime

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients
ssm = boto3.client('ssm')
dynamodb = boto3.resource('dynamodb')
s3 = boto3.client('s3')

# Get environment variables from Lambda configuration
TABLE_NAME = os.environ.get('TABLE_NAME')
SSM_PARAM_NAME = os.environ.get('SSM_PARAM_NAME')

def get_db_password():
    """Securely retrieve database password from SSM Parameter Store"""
    try:
        response = ssm.get_parameter(
            Name=SSM_PARAM_NAME,
            WithDecryption=True
        )
        logger.info("Successfully retrieved database password from SSM")
        return response['Parameter']['Value']
    except Exception as e:
        logger.error(f"Error retrieving password: {str(e)}")
        raise

def handler(event, context):
    """Lambda handler function"""
    try:
        # First get the database password
        password = get_db_password()
        
        # Process S3 events
        for record in event.get('Records', []):
            if record.get('eventSource') == 'aws:s3':
                bucket = record['s3']['bucket']['name']
                key = record['s3']['object']['key']
                
                # Get the file content
                response = s3.get_object(Bucket=bucket, Key=key)
                file_content = response['Body'].read().decode('utf-8')
                data = json.loads(file_content)
                
                # Save to DynamoDB
                table = dynamodb.Table(TABLE_NAME)
                item = {
                    'id': str(uuid.uuid4()),
                    'timestamp': datetime.utcnow().isoformat(),
                    'data': data
                }
                table.put_item(Item=item)
                
                logger.info(f"Successfully processed {key} from {bucket}")
        
        return {
            'statusCode': 200,
            'body': 'Success'
        }
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        raise