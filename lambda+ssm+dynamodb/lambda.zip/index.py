import boto3
import os
import json
import logging

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def handler(event, context):
    """
    Lambda handler that securely retrieves a password from SSM Parameter Store
    and demonstrates how to use it with DynamoDB
    """
    try:
        # Get environment variables set by Terraform
        table_name = os.environ['TABLE_NAME']
        ssm_param_name = os.environ['SSM_PARAM_NAME']
        
        logger.info(f"Retrieving parameter: {ssm_param_name} for table: {table_name}")
        
        # Get the password from SSM Parameter Store
        ssm_client = boto3.client('ssm')
        response = ssm_client.get_parameter(
            Name=ssm_param_name,
            WithDecryption=True
        )
        
        # Extract the decrypted password value
        db_password = response['Parameter']['Value']
        
        # Log success (but don't log the actual password!)
        logger.info(f"Successfully retrieved parameter: {ssm_param_name}")
        
        # Initialize DynamoDB client
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table(table_name)
        
        # Example: Put an item in DynamoDB
        # You can use the password here for authentication if needed
        # (In this example we're just demonstrating storing a test item)
        response = table.put_item(
            Item={
                'id': f'test-item-{context.aws_request_id}',
                'timestamp': str(context.invoked_function_arn),
                'password_retrieved': True,  # Flag to indicate password was retrieved, but don't store the password!
                'lambda_function': context.function_name
            }
        )
        
        logger.info(f"Put item in DynamoDB table: {table_name}")
        
        # If this function was triggered by S3 (as in your Terraform), process that event
        if event.get('Records') and event['Records'][0].get('eventSource') == 'aws:s3':
            bucket = event['Records'][0]['s3']['bucket']['name']
            key = event['Records'][0]['s3']['object']['key']
            logger.info(f"Function triggered by S3 event. Bucket: {bucket}, Key: {key}")
            
            # Process the S3 file here
            # This is where you would use the password if needed for external authentication
        
        return {
            'statusCode': 200,
            'body': json.dumps('Successfully processed request and retrieved secure parameter')
        }
        
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error: {str(e)}')
        }